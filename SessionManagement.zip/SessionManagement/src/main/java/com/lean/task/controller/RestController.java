package com.lean.task.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lean.task.exception.SessionException;
import com.lean.task.model.Session;
import com.lean.task.repository.SessionRepository;

import jakarta.validation.Valid;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/session")
public class RestController {

	@Autowired
	SessionRepository sessionRepository;
	
	
	@PostMapping("/book")
	public ResponseEntity<String> bookRecurringSession(@Valid @RequestBody Session session) {
	    session.setBookedAt(LocalDateTime.now()); 
	    sessionRepository.save(session);
	    return ResponseEntity.ok("Session booked successfully on "+session.getBookedAt()+ " for user to attend at "+session.getDate() +" and frequency is "+session.getFrequency()+" per month");
	}
	
	@DeleteMapping("/cancel/{sessionId}")
	public ResponseEntity<String> cancelSession(@PathVariable Long sessionId) {
	    Optional<Session> sessionOptional = sessionRepository.findById(sessionId);

	    if (sessionOptional.isPresent()) {
	        Session session = sessionOptional.get();
	        LocalDateTime currentTime = LocalDateTime.now();
	        LocalDateTime sessionTime = session.getDate();

	        Duration duration = Duration.between(currentTime, sessionTime);

	        if (duration.toHours() > 12) {
	        	sessionRepository.delete(session); 
	            return ResponseEntity.ok("Session canceled successfully.");
	        } else {
	            return ResponseEntity.badRequest().body("Session cannot be canceled within 12 hours of the session time.");
	        }
	    } else {
	    	throw new SessionException("No Session Found with Such id");
	    }
	}
	
	@PutMapping("/reschedule/{sessionId}")
	public ResponseEntity<String> rescheduleSession(@PathVariable Long sessionId, @RequestBody Session newSession) {
	    Optional<Session> sessionOptional = sessionRepository.findById(sessionId);

	    if (sessionOptional.isPresent()) {
	        Session session = sessionOptional.get();
	        LocalDateTime currentTime = LocalDateTime.now();
	        LocalDateTime newSessionTime = newSession.getDate();

	        Duration duration = Duration.between(currentTime, newSessionTime);

	        if (duration.toHours() > 4) {
	            session.setDate(newSessionTime);
	            sessionRepository.save(session);
	            return ResponseEntity.ok("Session rescheduled successfully.");
	        } else {
	            return ResponseEntity.badRequest().body("Session cannot be rescheduled within 4 hours of the new session time.");
	        }
	    } else {
	    	throw new SessionException("No Session Found with Such id");
	    }
	}
	@GetMapping
	public ResponseEntity<List<Session>> getSessions(){
		return new ResponseEntity<>(sessionRepository.findAll(),HttpStatus.ACCEPTED);
	}
	
}