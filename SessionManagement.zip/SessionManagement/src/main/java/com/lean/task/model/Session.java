package com.lean.task.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
public class Session {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Min(value = 1,message = "Input Valid User Id")
    private Long userId;
    @Min(value =1,message = "Input Valid Mentor Id")
    private Long mentorId;
    @NotNull(message = "Session Date must not be null ,pattern= yyyy-mm-ddThh:mm:ss.xxx.z , example = 2023-09-08T05:45:42.398Z")
    @Future(message = "Session Date must be in the future")
    private LocalDateTime date;
    @NotNull(message = "Booking Date must not be null ,pattern= yyyy-mm-ddThh:mm:ss.xxx.z , example = 2023-09-08T05:45:42.398Z")
    private LocalDateTime bookedAt;
    @Min(value=1,message = "Frequency of user booking session per month should be minimum one")
    private int frequency;

}