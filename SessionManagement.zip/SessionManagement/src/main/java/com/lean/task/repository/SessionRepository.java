package com.lean.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lean.task.model.Session;

public interface SessionRepository extends JpaRepository<Session, Long>{

}