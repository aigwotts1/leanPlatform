package com.lean.task.test.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lean.task.model.Session;
import com.lean.task.repository.SessionRepository;

@SpringBootTest
@AutoConfigureMockMvc
public class RestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private SessionRepository sessionRepository;
    
    LocalDate date = LocalDate.of(2023, 9,9);
    LocalTime time = LocalTime.of(14, 30);
    LocalDateTime dateTime = LocalDateTime.of(date, time);

    @Test
    public void testBookRecurringSession() throws Exception {
        Session session = new Session();
        session.setId(1L);
        session.setDate(dateTime);
        session.setBookedAt(LocalDateTime.now());
        session.setFrequency(1);

        when(sessionRepository.save(Mockito.any(Session.class))).thenReturn(session);

        String jsonRequest = objectMapper.writeValueAsString(session);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .post("/session/book")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonRequest))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(200, response.getStatus());
    }

    @Test
    public void testCancelSession() throws Exception {
        Session session = new Session();
        session.setId(1L);
        session.setDate(dateTime);
        session.setBookedAt(LocalDateTime.now());
        session.setFrequency(1);

        when(sessionRepository.findById(1L)).thenReturn(Optional.of(session));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .delete("/session/cancel/{sessionId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(200, response.getStatus());
    }

    @Test
    public void testRescheduleSession() throws Exception {
        Session session = new Session();
        session.setId(1L);
        session.setDate(dateTime);
        session.setBookedAt(LocalDateTime.now());
        session.setFrequency(1);

        when(sessionRepository.findById(1L)).thenReturn(Optional.of(session));

        Session requestSession = new Session();
        requestSession.setDate(LocalDateTime.now().plusDays(5));

        String jsonRequest = objectMapper.writeValueAsString(requestSession);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .put("/session/reschedule/{sessionId}", 1)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonRequest))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(200, response.getStatus());
    }

    @Test
    public void testGetSessions() throws Exception {
        List<Session> sessions = new ArrayList<>();
        sessions.add(new Session());
        sessions.add(new Session());

        when(sessionRepository.findAll()).thenReturn(sessions);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .get("/session")
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(202, response.getStatus());
    }
    
    @Test
    public void testCancelSessionNotFound() throws Exception {
        when(sessionRepository.findById(1L)).thenReturn(Optional.empty());

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .delete("/session/cancel/{sessionId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(400, response.getStatus()); 
    }

    @Test
    public void testCancelSessionTooClose() throws Exception {
        Session session = new Session();
        session.setId(1L);
        session.setDate(LocalDateTime.now().plusHours(8)); // Less than 12 hours from current time

        when(sessionRepository.findById(1L)).thenReturn(Optional.of(session));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .delete("/session/cancel/{sessionId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(400, response.getStatus()); 
    }

    @Test
    public void testRescheduleSessionTooClose() throws Exception {
        Session session = new Session();
        session.setId(1L);
        session.setDate(LocalDateTime.now().plusHours(2));

        when(sessionRepository.findById(1L)).thenReturn(Optional.of(session));

        Session requestSession = new Session();
        requestSession.setDate(LocalDateTime.now().plusHours(3));

        String jsonRequest = objectMapper.writeValueAsString(requestSession);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders
                .put("/session/reschedule/{sessionId}", 1)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonRequest))
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(400, response.getStatus());
    }
}